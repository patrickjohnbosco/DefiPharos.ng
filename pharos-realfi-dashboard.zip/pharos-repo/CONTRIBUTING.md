# Contributing to Pharos RealFi Dashboard

Thank you for your interest in contributing! This project is open to everyone
building on or around the Pharos Network ecosystem.

---

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How to Contribute](#how-to-contribute)
- [Development Setup](#development-setup)
- [Commit Message Convention](#commit-message-convention)
- [Pull Request Process](#pull-request-process)
- [Good First Issues](#good-first-issues)

---

## Code of Conduct

Be respectful. Be constructive. We're all here to build something useful for
the Pharos ecosystem. Harassment or gatekeeping of any kind will not be
tolerated.

---

## How to Contribute

### Reporting Bugs

1. Search [existing issues](../../issues) to avoid duplicates
2. Use the **Bug Report** issue template
3. Include your browser, OS, and steps to reproduce

### Suggesting Features

1. Open a **Feature Request** issue
2. Describe the user problem it solves
3. Reference relevant Pharos protocol documentation if applicable

### Submitting Code

1. Fork the repo
2. Create a feature branch: `git checkout -b feat/your-feature-name`
3. Make your changes
4. Test in at least Chrome and Firefox
5. Submit a pull request against `main`

---

## Development Setup

No build tools required. Just:

```bash
git clone https://github.com/YOUR_USERNAME/pharos-realfi-dashboard.git
cd pharos-realfi-dashboard

# Open in browser
open index.html

# Or use a local dev server (optional, for hot reload)
npx serve .
# or
python3 -m http.server 8080
```

All code lives in `index.html`. Sections are clearly commented:
- `<!-- HEADER -->` — brand bar and network status
- `<!-- CHAIN STATS -->` — vitals grid
- `<!-- MAIN GRID -->` — portfolio, dApps, tx feed
- `<!-- BOTTOM ROW -->` — yield, RWA table, SPN, PROS
- `<!-- TICKER BAR -->` — bottom price ticker
- `<script>` — all live simulation logic

---

## Commit Message Convention

We use [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <short summary>

Types:
  feat      New feature
  fix       Bug fix
  docs      Documentation only
  style     CSS / visual changes (no logic change)
  refactor  Code restructure (no behaviour change)
  perf      Performance improvement
  chore     Build, tooling, dependency changes
```

**Examples:**
```
feat(portfolio): add wallet address input for live balances
fix(ticker): prevent NaN on USDC price update
docs(readme): add RPC integration guide
style(cards): increase card border radius to 14px
```

---

## Pull Request Process

1. **One concern per PR.** Keep PRs focused — don't bundle unrelated changes.
2. **Update `CHANGELOG.md`** under `[Unreleased]` for any user-facing change.
3. **Test responsiveness** — verify your changes work on mobile widths.
4. **No external dependencies** unless absolutely necessary and discussed first.
   The zero-dependency nature of this project is a core feature.
5. PRs are merged by maintainers after at least one review approval.

---

## Good First Issues

These are great starting points if you're new to the project:

| Issue | Difficulty | Description |
|-------|------------|-------------|
| Real block number | Easy | Poll Pharos RPC for live block number |
| Theme toggle | Easy | Add a dark/light mode switch |
| Address input | Medium | Let users enter wallet address to see real balances |
| Live TVL | Medium | Integrate Pharos subgraph for real dApp TVL |
| PROS price oracle | Medium | Fetch PROS/USD from PharosDEX on-chain |
| PWA support | Hard | Add service worker + manifest for installability |

---

## Questions?

Open a [Discussion](../../discussions) or reach out in the
[Pharos Network Discord](https://discord.gg/pharosnetwork).
