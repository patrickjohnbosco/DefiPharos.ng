# Changelog

All notable changes to **Pharos RealFi Dashboard** are documented here.

This project follows [Semantic Versioning](https://semver.org/) and
[Keep a Changelog](https://keepachangelog.com/en/1.0.0/) conventions.

---

## [Unreleased]

### Planned
- Real Pharos RPC integration for live block data
- Wallet connect support (MetaMask / WalletConnect v2)
- Real portfolio balances via on-chain address lookup
- Live dApp TVL from Pharos subgraph endpoints
- PROS/USD price from PharosDEX on-chain oracle

---

## [1.0.0] — 2026-05-01

### 🎉 Initial Release — Pacific Ocean Mainnet Launch

This is the first public release of the Pharos RealFi Dashboard, shipped on
the same week as Pharos Network's Pacific Ocean Mainnet launch (April 28, 2026).

### Added
- **Chain Vitals panel** — live-simulated TPS, total transactions, finality,
  RWA TVL, and active dApp count with animated progress bars
- **RWA Portfolio Tracker** — donut allocation chart across Treasuries, Credit,
  Real Estate, and Commodities asset classes with per-asset breakdown
- **Ecosystem dApp Explorer** — 8 live Pharos mainnet protocols with TVL and
  24h change indicators (PharosDEX, Morpho, Bitverse Perp, PharosOracle,
  pAlpha Vault, AutoStaking AI, Orbiter Bridge, zkDID Identity)
- **Live Transaction Feed** — streaming simulated on-chain activity updating
  every 1.1 seconds across 8 transaction types
- **Yield Opportunities chart** — ranked APY comparison with animated bar fills
  from 16% (pAlpha Vault) to 5% (PROS staking)
- **On-Chain RWA Asset Registry** — table of tokenized assets (JTRSY, JAAA,
  PHRE-01, CMDX, GCL-ENRG) with yield and compliance status
- **SPN Network Monitor** — real-time status for RWA Settlement, AI Inference,
  HFT Trading, and DePIN SPNs
- **$PROS Token Tracker** — live price simulation, staking lock percentage,
  and roadmap milestone checklist
- **Live price ticker bar** — persistent bottom bar with 8 assets updating
  every 4 seconds
- **Animated ocean-themed UI** — deep navy background, teal/gold accent system,
  scanline animation, CSS noise texture, and pulse effects
- **Fully responsive layout** — 3-column desktop, 2-column tablet, 1-column mobile
- **Zero-dependency architecture** — single HTML file, no build tools required

### Design
- Nautical / deep-sea aesthetic reflecting Pharos's "Pacific Ocean Mainnet" branding
- Color system: `#00c8b4` teal, `#e8c16a` gold, `#3ed98a` green, `#e8564a` red
- Typography: Syne (headings), DM Mono (data), Crimson Pro (prose)
- Ambient radial gradients, CSS noise overlay, animated scanline

---

## [0.9.0] — 2026-04-29 (Pre-release / Internal)

### Added
- Initial prototype with static chain stats and placeholder dApp grid
- Basic portfolio donut chart (static)
- Skeleton ticker bar layout

### Changed
- Switched from React prototype to single-file HTML for zero-dependency deployment

### Removed
- Removed bundler dependency (Vite config scrapped)

---

[Unreleased]: https://github.com/YOUR_USERNAME/pharos-realfi-dashboard/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/YOUR_USERNAME/pharos-realfi-dashboard/releases/tag/v1.0.0
[0.9.0]: https://github.com/YOUR_USERNAME/pharos-realfi-dashboard/releases/tag/v0.9.0
