# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 1.x     | ✅ Yes     |
| 0.x     | ❌ No      |

## Reporting a Vulnerability

If you discover a security vulnerability in this project, **please do not open a public issue.**

Instead, email: **security@[your-domain].com**

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

You will receive a response within **48 hours** and a fix timeline within **7 days**
for confirmed vulnerabilities.

## Scope

This is a frontend-only, read-only dashboard. It holds no private keys,
stores no credentials, and makes no authenticated API calls. The primary
security concern is **third-party RPC endpoint trust** when live data
integration is added in future versions.
