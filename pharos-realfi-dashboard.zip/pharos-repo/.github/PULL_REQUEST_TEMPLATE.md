## Summary
<!-- What does this PR do? One or two sentences. -->

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Style / visual change
- [ ] Performance improvement
- [ ] Refactor

## Related Issue
Closes #<!-- issue number -->

## Changes Made
<!-- List the specific files and what changed in each -->

## Testing
- [ ] Tested in Chrome
- [ ] Tested in Firefox
- [ ] Tested on mobile (or mobile viewport)
- [ ] No regressions in existing panels

## CHANGELOG Updated
- [ ] Added entry under `[Unreleased]` in `CHANGELOG.md`

## Screenshots (if visual change)
<!-- Before / After -->
