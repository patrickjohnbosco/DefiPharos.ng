---
name: Bug Report
about: Something is broken or displaying incorrectly
title: '[BUG] '
labels: bug
assignees: ''
---

## Describe the Bug
A clear description of what is wrong.

## Steps to Reproduce
1. Open `index.html` in [browser]
2. Navigate to [section]
3. Observe [issue]

## Expected Behavior
What should happen instead.

## Screenshots
If applicable, add screenshots.

## Environment
- OS: [e.g. macOS 15, Windows 11]
- Browser: [e.g. Chrome 124, Firefox 125, Safari 17]
- Version: [e.g. v1.0.0]
- Deployment: [Local file / GitHub Pages / Netlify]

## Additional Context
Any other relevant information.
