---
name: Feature Request
about: Suggest a new feature or improvement for the dashboard
title: '[FEAT] '
labels: enhancement
assignees: ''
---

## Problem Statement
What user problem does this feature solve? Who benefits?

## Proposed Solution
Describe the feature you'd like to see.

## Pharos Protocol Context
Is this feature tied to a specific Pharos protocol, SPN, or dApp?
Link any relevant docs or contracts.

## Alternatives Considered
Any other approaches you considered?

## Additional Context
Mockups, screenshots, or references welcome.
