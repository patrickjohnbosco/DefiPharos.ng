# ⚓ Pharos RealFi Dashboard

> **The missing portfolio intelligence layer for the Pharos Network ecosystem.**

A real-time, single-file RWA (Real World Asset) portfolio dashboard and ecosystem explorer built natively for the [Pharos Network](https://pharosnetwork.xyz) — the first EVM-compatible Layer 1 designed for institutional-grade DeFi and tokenized real-world assets.

![License](https://img.shields.io/badge/license-MIT-teal.svg)
![Status](https://img.shields.io/badge/status-live-brightgreen.svg)
![Network](https://img.shields.io/badge/network-Pharos%20Mainnet-blue.svg)
![Built For](https://img.shields.io/badge/built%20for-Pharos%20Pacific%20Ocean%20Mainnet-gold.svg)

---

## 🌊 Why This Exists

Pharos Network launched its Pacific Ocean Mainnet on **April 28, 2026**. The chain is purpose-built for tokenized Real World Assets, institutional DeFi, and high-throughput financial primitives — boasting up to **50,000 TPS**, **sub-second finality**, and a modular **Special Processing Network (SPN)** architecture.

Yet as the ecosystem grew, a critical gap emerged: **there was no unified dashboard** where users could:

- Track their RWA portfolio positions across multiple protocols
- Monitor live chain health and transaction throughput
- Compare yield opportunities across lending, vaulting, and staking
- Discover and assess ecosystem dApps in one place
- Understand SPN subnet status in real time

This dashboard fills that gap. It is the **RealFi control center** Pharos users needed on day one.

---

## ✨ Features

### 📊 Chain Vitals (Live)
| Metric | Description |
|--------|-------------|
| Network TPS | Real-time throughput against 50K capacity |
| Total Transactions | Cumulative on-chain activity |
| Finality | Block confirmation time (target: sub-second) |
| RWA TVL | Total value locked in tokenized asset protocols |
| Active dApps | Count of live ecosystem applications |

### 💼 RWA Portfolio Tracker
- **Donut allocation chart** across asset classes (Treasuries, Credit, Real Estate, Commodities)
- **Live USD portfolio value** with monthly P&L
- Per-asset breakdown with percentage weight and notional value
- Supports JTRSY, JAAA, PHRE-01, CMDX, GCL-ENRG and custom assets

### 🏛️ Ecosystem dApp Explorer
All major Pharos mainnet protocols displayed with live TVL and 24h change:
- **PharosDEX** — Spot exchange
- **Morpho (Pharos)** — RWA lending markets
- **Bitverse Perp** — Perpetuals DEX
- **PharosOracle** — Chainlink CCIP price feeds
- **pAlpha Vault** — Institutional RWA yield vault
- **AutoStaking AI** — AI-powered yield aggregator
- **Orbiter Bridge** — ETH ↔ Pharos cross-chain bridge
- **zkDID Identity** — Primus Labs zkTLS + zkFHE compliance layer

### 📈 Yield Opportunities
Ranked yield comparison across the ecosystem:
- pAlpha High Yield RWA Vault — **16.0% APY**
- AutoStaking AI Aggregator — **10.8% APY**
- Real Estate Fund LP — **8.4% APY**
- AAA Credit (JAAA) Lending — **6.2% APY**
- PROS Validator Staking — **5.0% APY**

### 🔗 On-Chain RWA Asset Registry
Live table of tokenized assets with yield, compliance status (zkKYC / SPN), and TVL.

### ⚡ SPN Network Monitor
Real-time status of all active Special Processing Networks:
- RWA Settlement SPN
- AI Inference SPN (ZKML + TEE)
- HFT Trading SPN
- DePIN Infrastructure SPN

### 🪙 $PROS Token Tracker
- Live price feed with TGE delta
- Staking lock percentage
- Roadmap milestone tracker

### 📡 Live Transaction Feed
Streaming simulation of on-chain activity: swaps, RWA deposits, borrows, bridges, yield claims, and perpetual trades — updating every 1.1 seconds.

### 📉 Price Ticker Bar
Persistent bottom ticker with live-updating prices for PROS, JTRSY, JAAA, ETH, BTC, PHRE-01, CMDX, and USDC.

---

## 🚀 Quick Start

No build tools. No dependencies. No Node.js. One file.

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/pharos-realfi-dashboard.git

# Open directly in your browser
open index.html
```

Or visit the live deployment:
**[https://YOUR_USERNAME.github.io/pharos-realfi-dashboard](https://YOUR_USERNAME.github.io/pharos-realfi-dashboard)**

---

## 📁 Repository Structure

```
pharos-realfi-dashboard/
├── index.html          # Complete dashboard (self-contained)
├── README.md           # This file
├── LICENSE             # MIT License
├── CHANGELOG.md        # Version history
├── CONTRIBUTING.md     # Contribution guidelines
└── .github/
    └── ISSUE_TEMPLATE/
        ├── bug_report.md
        └── feature_request.md
```

---

## 🔌 Connecting to Real Pharos RPC

The dashboard currently runs on simulated live data. To connect to the real Pharos Network:

**Mainnet RPC Endpoints:**
```
https://mainnet.pharosnetwork.xyz/rpc
wss://mainnet.pharosnetwork.xyz/ws
```

**Chain ID:** `1130` (verify on official docs)

To wire up real data, replace the JS simulation blocks in `index.html` with `ethers.js` or `viem` calls:

```javascript
import { createPublicClient, http } from 'viem'

const client = createPublicClient({
  transport: http('https://mainnet.pharosnetwork.xyz/rpc')
})

// Fetch real block number
const block = await client.getBlockNumber()
```

---

## 🗺️ Roadmap

- [x] v1.0 — Core dashboard with simulated live data
- [ ] v1.1 — Real RPC integration (block number, TPS, finality)
- [ ] v1.2 — Wallet connect (MetaMask / WalletConnect)
- [ ] v1.3 — Real portfolio balances via address input
- [ ] v1.4 — Live dApp TVL from Pharos subgraph
- [ ] v1.5 — PROS price from PharosDEX on-chain oracle
- [ ] v2.0 — Multi-wallet portfolio aggregation
- [ ] v2.1 — Alerts & notifications for yield changes
- [ ] v2.2 — Mobile-native PWA wrapper

---

## 🤝 Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

**Good first issues:**
- Replace simulated TPS with real RPC polling
- Add wallet address input for real portfolio balances
- Integrate Pharos subgraph for live TVL data
- Add dark/light theme toggle

---

## 📜 License

MIT — see [LICENSE](LICENSE) for full terms. Free to fork, modify, and deploy.

---

## 🙏 Acknowledgements

- [Pharos Network](https://pharosnetwork.xyz) — for building the infrastructure this dashboard serves
- [Morpho Protocol](https://morpho.org) — RWA lending markets on Pharos
- [Centrifuge](https://centrifuge.io) — tokenized real-world asset protocols
- [Primus Labs](https://primuslabs.xyz) — zkTLS + zkFHE identity layer
- [Orbiter Finance](https://orbiter.finance) — cross-chain bridge infrastructure

---

<div align="center">
  <sub>Built with ⚓ for the Pharos ecosystem · Pacific Ocean Mainnet · 2026</sub>
</div>
